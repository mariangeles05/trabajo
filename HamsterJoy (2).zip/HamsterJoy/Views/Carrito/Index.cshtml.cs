    using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HamsterJoy.Views.Carrito;

public class Index : PageModel
{
    public void OnGet()
    {
        
    }
}