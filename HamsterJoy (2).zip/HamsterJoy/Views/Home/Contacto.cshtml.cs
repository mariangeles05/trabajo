using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HamsterJoy.Views.Home;

public class Contacto : PageModel
{
    public void OnGet()
    {
        
    }
}