using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HamsterJoy.Views.Home;

public class Productos : PageModel
{
    public void OnGet()
    {
        
    }
}