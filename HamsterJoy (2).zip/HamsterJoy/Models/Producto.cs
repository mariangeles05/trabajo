using System.ComponentModel.DataAnnotations;

namespace HamsterJoy.Models
{
    public class Producto
{
    public int Id { get; set; }
    public string Nombre { get; set; }
    public decimal Precio { get; set; }
    public string Imagen { get; set; } // Solo el nombre del archivo
    public string Descripcion { get; set; }
    
    // Propiedad calculada para la ruta completa
    public string ImagenUrl => $"/images/products/{Imagen}";
}
}