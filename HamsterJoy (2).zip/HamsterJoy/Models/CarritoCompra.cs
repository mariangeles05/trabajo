using System.Collections.Generic;
using System.Linq;

namespace HamsterJoy.Models
{
    public class CarritoCompra
    {
        public List<CarritoItem> Items { get; set; } = new List<CarritoItem>();
        
        public decimal Total => Items.Sum(i => i.Subtotal);
        public int TotalItems => Items.Sum(i => i.Cantidad);
        
        public void AgregarItem(Producto producto, int cantidad = 1)
        {
            var existingItem = Items.FirstOrDefault(i => i.ProductoId == producto.Id);
            
            if (existingItem != null)
            {
                existingItem.Cantidad += cantidad;
            }
            else
            {
                Items.Add(new CarritoItem
                {
                    ProductoId = producto.Id,
                    Nombre = producto.Nombre,
                    Precio = producto.Precio,
                    Cantidad = cantidad,
                    Imagen = producto.Imagen
                });
            }
        }
        
        public void EliminarItem(int productoId)
        {
            Items.RemoveAll(i => i.ProductoId == productoId);
        }
        
        public void ActualizarCantidad(int productoId, int cantidad)
        {
            var item = Items.FirstOrDefault(i => i.ProductoId == productoId);
            if (item != null)
            {
                if (cantidad <= 0)
                    EliminarItem(productoId);
                else
                    item.Cantidad = cantidad;
            }
        }
        
        public void Limpiar()
        {
            Items.Clear();
        }
    }
}