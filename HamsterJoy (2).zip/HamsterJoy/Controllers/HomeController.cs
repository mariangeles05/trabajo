using Microsoft.AspNetCore.Mvc;
using HamsterJoy.Models;
using System.Collections.Generic;

namespace HamsterJoy.Controllers
{
    public class HomeController : Controller
    {
        private readonly List<Producto> _productos = new List<Producto>
        {
            // Productos existentes (1-6)
            new Producto 
            { 
                Id = 1, 
                Nombre = "Rueda Ejercitadora", 
                Precio = 25.99m, 
                Imagen = "rueda-ejercitadora.jpg",
                Descripcion = "Rueda silenciosa para que tu hámster haga ejercicio sin molestias."
            },
            new Producto 
            { 
                Id = 2, 
                Nombre = "Casa de Madera", 
                Precio = 18.50m, 
                Imagen = "casa-madera.jpg",
                Descripcion = "Casa acogedora de madera natural para el descanso de tu mascota."
            },
            new Producto 
            { 
                Id = 3, 
                Nombre = "Hamaca Colgante", 
                Precio = 12.75m, 
                Imagen = "hamaca-colgante.jpg",
                Descripcion = "Hamaca suave y cómoda para que tu hámster descanse plácidamente."
            },
            new Producto 
            { 
                Id = 4, 
                Nombre = "Túnel de Juego", 
                Precio = 15.25m, 
                Imagen = "tunel-juego.jpg",
                Descripcion = "Túnel de plástico seguro para explorar y jugar."
            },
            new Producto 
            { 
                Id = 5, 
                Nombre = "Comedero Automático", 
                Precio = 22.99m, 
                Imagen = "comedero-automatico.jpg",
                Descripcion = "Dispensador de comida que mantiene el alimento fresco y disponible."
            },
            new Producto 
            { 
                Id = 6, 
                Nombre = "Bebedero de Botella", 
                Precio = 8.99m, 
                Imagen = "bebedero-botella.jpg",
                Descripcion = "Bebedero de agua que evita derrames y mantiene el agua limpia."
            },

            // NUEVOS PRODUCTOS (7-20)
            new Producto 
            { 
                Id = 7, 
                Nombre = "Jaula Espaciosa", 
                Precio = 45.00m, 
                Imagen = "jaula-espaciosa.jpg",
                Descripcion = "Jaula grande con múltiples niveles para que tu hámster explore."
            },
            new Producto 
            { 
                Id = 8, 
                Nombre = "Rueda de Ejercicio Silenciosa", 
                Precio = 30.50m, 
                Imagen = "rueda-silenciosa.jpg",
                Descripcion = "Rueda de ejercicio ultra silenciosa para no molestar en la noche."
            },
            new Producto 
            { 
                Id = 9, 
                Nombre = "Cama Suave", 
                Precio = 10.00m, 
                Imagen = "cama-suave.jpg",
                Descripcion = "Cama suave y cómoda para el descanso de tu hámster."
            },
            new Producto 
            { 
                Id = 10, 
                Nombre = "Comida Balanceada", 
                Precio = 12.00m, 
                Imagen = "comida-balanceada.jpg",
                Descripcion = "Alimento balanceado con todos los nutrientes necesarios."
            },
            new Producto 
            { 
                Id = 11, 
                Nombre = "Snacks de Frutas", 
                Precio = 5.50m, 
                Imagen = "snacks-frutas.jpg",
                Descripcion = "Deliciosos snacks de frutas naturales para tu hámster."
            },
            new Producto 
            { 
                Id = 12, 
                Nombre = "Bola de Ejercicio", 
                Precio = 15.00m, 
                Imagen = "bola-ejercicio.jpg",
                Descripcion = "Bola de ejercicio para que tu hámster corra libremente por la casa."
            },
            new Producto 
            { 
                Id = 13, 
                Nombre = "Escondite de Madera", 
                Precio = 8.00m, 
                Imagen = "escondite-madera.jpg",
                Descripcion = "Pequeño escondite de madera para que tu hámster se sienta seguro."
            },
            new Producto 
            { 
                Id = 14, 
                Nombre = "Rampa de Madera", 
                Precio = 7.50m, 
                Imagen = "rampa-madera.jpg",
                Descripcion = "Rampa de madera para conectar diferentes niveles en la jaula."
            },
            new Producto 
            { 
                Id = 15, 
                Nombre = "Columpio de Cuerda", 
                Precio = 9.00m, 
                Imagen = "columpio-cuerda.jpg",
                Descripcion = "Divertido columpio de cuerda para el entretenimiento de tu hámster."
            },
            new Producto 
            { 
                Id = 16, 
                Nombre = "Mordedor de Madera", 
                Precio = 4.00m, 
                Imagen = "mordedor-madera.jpg",
                Descripcion = "Mordedor de madera natural para ayudar a desgastar los dientes de tu hámster."
            },
            new Producto 
            { 
                Id = 17, 
                Nombre = "Fuente de Agua", 
                Precio = 25.00m, 
                Imagen = "fuente-agua.jpg",
                Descripcion = "Fuente de agua automática que mantiene el agua fresca y circulante."
            },
            new Producto 
            { 
                Id = 18, 
                Nombre = "Casa de Cerámica", 
                Precio = 20.00m, 
                Imagen = "casa-ceramica.jpg",
                Descripcion = "Casa de cerámica que mantiene una temperatura fresca en verano."
            },
            new Producto 
            { 
                Id = 19, 
                Nombre = "Tubo de Cartón", 
                Precio = 3.00m, 
                Imagen = "tubo-carton.jpg",
                Descripcion = "Tubo de cartón natural para que tu hámster roa y se esconda."
            },
            new Producto 
            { 
                Id = 20, 
                Nombre = "Rascador de Uñas", 
                Precio = 6.00m, 
                Imagen = "rascador-unas.jpg",
                Descripcion = "Rascador de uñas para mantener las uñas de tu hámster en buen estado."
            }
        };

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Productos()
        {
            return View(_productos);
        }

        public IActionResult Contacto()
        {
            return View();
        }
    }
}